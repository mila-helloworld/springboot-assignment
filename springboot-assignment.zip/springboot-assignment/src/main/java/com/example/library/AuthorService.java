package com.example.library;

import java.util.List;

public interface AuthorService {
    List<Author> findAll();
}
